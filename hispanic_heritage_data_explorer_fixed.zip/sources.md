# Sources and indicator definitions

## Primary source
World Bank Indicators API: https://datahelpdesk.worldbank.org/knowledgebase/articles/889392-about-the-indicators-api-documentation

The app requests country-level indicator observations through endpoints of the form:

`https://api.worldbank.org/v2/country/{ISO3}/indicator/{INDICATOR_CODE}?date={START}:{END}&format=json`

The app requests the current year minus 70 through current year minus 1, inclusive. It reports the returned observation count and actual coverage rather than assuming all years exist. The API is public and does not require credentials.

## Country codes
Mexico MEX; Brazil BRA; Argentina ARG; Colombia COL; Chile CHL; Peru PER; Venezuela VEN; Ecuador ECU; Uruguay URY.

Brazil is included as a Latin American comparison country.

## Indicators
| App label | World Bank code | Units / interpretation |
|---|---|---|
| Life expectancy at birth | `SP.DYN.LE00.IN` | Years; life expectancy at birth under current age-specific mortality patterns. |
| Unemployment, national estimate | `SL.UEM.TOTL.NE.ZS` | Percent of labor force; national-estimate unemployment. |
| GDP per capita | `NY.GDP.PCAP.CD` | Current US dollars per person; GDP divided by midyear population, not average wealth or household income. |
| Crude birth rate | `SP.DYN.CBRT.IN` | Births per 1,000 people per year; a rate, not a birth count. |
| Net migration | `SM.POP.NETM` | People; net migration, not an emigration count. |
| Intentional homicide rate | `VC.IHR.PSRC.P5` | Intentional homicides per 100,000 people. |
| Consumer price inflation | `FP.CPI.TOTL.ZG` | Annual percent change in consumer price index. |
| Central government debt | `GC.DOD.TOTL.GD.ZS` | Percent of GDP. |
| Total reserves including gold | `FI.RES.TOTL.CD` | Current US dollars. |
| External balance on goods/services | `NE.RSB.GNFS.ZS` | Percent of GDP. |

## Retrieval and modeling notes
- Retrieval date is generated locally when the app runs.
- Null observations are omitted from the working data table; they are not replaced with fabricated or random values.
- Source data and the editable scenario are held separately in app session state.
- A polynomial of degree `d` requires at least `d + 1` distinct years.
- Residuals are observed minus fitted values. R² and MAE are in-sample metrics unless labeled chronological holdout.
- Extrapolation is uncertain. The app does not claim that its estimates are validated prediction intervals.
- Suggested functions in the Function Lab are illustrative examples, not sourced empirical models.
