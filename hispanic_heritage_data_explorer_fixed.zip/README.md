# Hispanic Heritage Historical Data Explorer

A self-contained Streamlit app for exploring historical World Bank indicators and learning about polynomial models and calculus.

## Files
- `app.py` — complete Streamlit app
- `requirements.txt` — minimal, unpinned dependencies
- `sources.md` — source definitions and indicator mappings

## Run locally
Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
python -m streamlit run app.py
```

## Deploy on Streamlit Community Cloud
1. Create a GitHub repository.
2. Upload `app.py`, `requirements.txt`, `README.md`, and `sources.md` to the repository root.
3. In Streamlit Community Cloud, create an app from that repository and choose `app.py` as the main file.
4. Deploy. The app fetches public World Bank data at runtime; no API key is required.
5. If deployment fails, open the app's logs. Check the Python version, dependency installation, network access, and the traceback.

## Deploy on Render
Create a **Python Web Service** connected to the GitHub repository.

Build command:
```bash
pip install -r requirements.txt
```

Start command (single line):
```bash
python -m streamlit run app.py --server.address=0.0.0.0 --server.port=$PORT
```

## How the app works
1. The sidebar selects country, indicator, polynomial degree, marker increment, extrapolation horizon, course pathway, comparison country, and printer view.
2. The app requests data from the World Bank API and caches successful/empty results for one hour.
3. The source table is retained separately from the editable working table. Reset restores the source table.
4. A centered-time polynomial is fit only when the table passes validation and contains at least degree + 1 distinct years.
5. In-sample R² and MAE describe the fit to the working observations. A chronological holdout score is shown separately when enough rows exist.
6. The Function Lab supports suggested and custom functions, derivatives, tangent/secant lines, and numerical/symbolic analysis.
7. CSV, Excel, and PDF exports are generated in their actual file formats.

## Verification checklist
- Compare the selected country/indicator/year/value against the World Bank link in the app.
- Edit a value, confirm the user-modified scenario warning, then reset.
- Test duplicate years, decimal years, nonnumeric values, negative values for nonnegative indicators, and insufficient observations.
- Calculate one year with the single-year and batch tools; the estimates should agree.
- Try malformed expressions such as `x + )`, and functions with domain restrictions such as `log(x)` at negative x.
- Change each sidebar control and verify its intended output changes.
- Open each downloaded CSV, XLSX, and PDF.
- On deployment, inspect logs if the app does not start.

## Interpretation and limitations
Polynomial fitting is descriptive and can overfit. It does not explain historical causes and should not be treated as a reliable long-range forecast. Extrapolations are not validated 95% prediction intervals. World Bank observations may be missing, revised, or reported on different schedules. Custom symbolic analysis is strongest for common expressions and may not fully solve every transcendental equation. The context examples are simplified learning models, not professional medical, financial, weather, or engineering guidance.
